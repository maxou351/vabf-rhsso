# Rapport d'installation RedHat SSO

=========

## Activation des services

mariadb - Erreur : Could not find the requested service mariadb: host
haproxy - Erreur : Could not find the requested service haproxy: host
jboss - Erreur : Could not find the requested service jboss: host
firewalld - Erreur : Could not find the requested service firewalld: host
nginx - Erreur : Could not find the requested service nginx: host

## Domaine

    OK : Le domaine : http://localhost:8080 est accessible


## Royaume et accès à celui-ci

    OK : Le royaume master existe et est accessible via l'utilisateur kuser

## Endpoints accessibles

    OK : Tous les endpoints sont actifs et accessibles

=========

# Si tous les indicateurs sont à OK, l'installation de Red Hat SSO est réussie