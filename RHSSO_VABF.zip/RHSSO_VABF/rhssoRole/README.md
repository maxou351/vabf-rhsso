Role Name
=========

Ce rôle vérifie la bonne installation et le bon fonctionnement de RHSSO

Requirements
------------



Role Variables
--------------

main_path: "/home/osboxes/"
rapport_file_path : "rapport.txt"

# Paramètres RHSSO
domain_name: 
port: 433
id:

# Authentification RHSSO
auth:
  client_id:
  keycloak_id:
  realm:
  username:
  password:

services_list:
  - mariadb
  - haproxy
  - jboss
  - firewalld
  - nginx

Example Playbook
----------------


Author Information
------------------

Max MORELLI <m.morelli.ext@intradef.gouv.fr>
