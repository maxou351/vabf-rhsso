from __future__ import absolute_import, division, print_function
__metaclass__ = type

DOCUMENTATION = '''
---
module: keycloak_user_info
short_description: Permet l'accès aux données utilisateur via l'API keycloak
version_added: 3.0.0
description:
    - Ce module permet l'accès aux informations utilisateurs via Keycloak REST API. 
    Il necessite l'accès à l'API Rest via OIDC
options:
    realm:
        description:
            - Le nom du royaume
        type: str
    keycloak_url:
        type: str
        required=True
    username:
        type: str
    password:
        type: str
    token:
        type: str
author:
    - Max MORELLI <m.morelli.ext@intradef.gouv.fr>
'''

EXAMPLES = '''
- name: Get user information
  keycloak_realm:
    keycloak_url: https://auth.example.com/auth
    realm: master
    username: USERNAME
    password: PASSWORD
    realm: realm
'''

RETURN = '''
msg:
    description: Retourne les infos de l'utilisateur ou bien les erreurs rencontrées dans le cas d'un échec
    returned: always
    type: str
'''

import json
import traceback

from ansible.module_utils.urls import open_url
from ansible.module_utils.six.moves.urllib.parse import urlencode
from ansible.module_utils.six.moves.urllib.error import HTTPError
from ansible.module_utils.common.text.converters import to_native, to_text
from ansible.module_utils.basic import AnsibleModule

URL_REALM = "{url}/admin/realms/{realm}"
URL_USER_INFO = "{url}/realms/{realm}/protocol/openid-connect/userinfo"
URL_TOKEN = "{url}/realms/{realm}/protocol/openid-connect/token"

def get_token(module_params):
    """ Obtient le header de connection avec le token nécessaire pour la connexion à l'API"""
    token = module_params.get('token')
    base_url = module_params.get('keycloak_url')

    if not base_url.lower().startswith(('http', 'https')):
        raise KeycloakError("L\'url '{}' devrait commencer par 'http' ou 'https'.".format(base_url))

    if token is None:
        base_url = module_params.get('keycloak_url')
        realm = module_params.get('realm')
        username = module_params.get('username')
        password = module_params.get('password')
        url = URL_TOKEN.format(url=base_url, realm=realm)
        temp_payload = {
            'grant_type': 'password',
            'client_id': 'admin-cli'
            'username': username,
            'password': password,
        }
        try:
            r = json.loads(
                to_native(
                    open_url(
                        url, 
                        method = 'POST',
                        validate_certs = True, 
                        http_agent = 'Ansible', 
                        timeout = 10,
                        data = urlencode(payload)
                    ).read()
                ))
        except HTTPError as e:
            if e.code == 401:
                raise KeycloakError(
                'L\'API renvoit une erreur d\'authentification, vérifiez vos credentials: {}'
                    .format(str(e)))
            elif e.code == 400:
                raise KeycloakError(
                'L\'API renvoit une erreur de requête, vérifiez vos paramètres:  {}'
                    .format(str(e)))
            elif e.code == 404:
                raise KeycloakError(
                'L\'API renvoit une erreur, vérifiez les données du royaume (url et nom):  {}'
                    .format(str(e)))
            else:
                raise KeycloakError(
                'L\'API renvoit une erreur inconnue, vérifiez vos paramètres: {}'
                    .format(str(e)))
        except ValueError as e:
            raise KeycloakError(
                'L\'API retourne un JSON invalide en essayant d\'obtenir un access token via {}: {}'
                    .format(url, str(e)))
        except Exception as e:
            raise KeycloakError(
                'Impossible d\'obtenir le token via {}: {}'
                    .format(url, str(e)))

        try:
            token = r['access_token']
        except KeyError:
            raise KeycloakError(
                'Impossible d\'obtenir le token via {}'.format(url))
    return {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json'
    }

# Certaines erreurs peuvent être imprécises
class KeycloakError(Exception):
    pass

class KeycloakAPI(object):
    """ Accès à l'API Keycloak """
    def __init__(self, module, connection_header):
        self.module = module
        self.realm = self.module.params.get('realm')
        self.baseurl = self.module.params.get('keycloak_url')
        self.restheaders = connection_header

    def get_user_info(self):
        gestion_erreur = "Récupération des infos utilisateur"
        user_info_url = URL_USER_INFO.format(url=self.baseurl, realm=self.realm)

        try:
            return json.loads(
                to_native(
                    open_url(
                        user_info_url, 
                        method = 'GET', 
                        http_agent = 'Ansible', 
                        headers = self.restheaders, 
                        timeout = 10
                        validate_certs = True
                    ).read()
                )
            )
        except Exception as e:
            self.module.fail_json(
                msg = 'Impossible d\'obtenir les infos de l\'utilisateur {}: {}'.format(realm, str(e)),
                exception = traceback.format_exc()
            )
    
    def get_realm_by_id(self):
        realm_url = URL_REALM.format(url=self.baseurl, realm=self.realm)

        try:
            return json.loads(
                to_native(
                    open_url(
                        realm_url, 
                        method = 'GET', 
                        http_agent = 'Ansible', 
                        headers = self.restheaders, 
                        timeout = 10
                        validate_certs = True
                    ).read()
                ))
        except HTTPError as e:
            if e.code == 404:
                self.module.fail_json( 
                    msg='Erreur durant la {}. Le royaume {} n\'existe pas: {}'
                        .format(gestion_erreur, realm, str(e)),
                    exception=traceback.format_exc()
                )
            elif e.code == 403:
                self.module.fail_json( 
                    msg='Erreur durant la {}. Le royaume {} existe mais impossible d\'y accéder, vérifiez votre configuration: {}'
                        .format(gestion_erreur, realm, str(e)),
                    exception=traceback.format_exc()
                )
            elif e.code == 401:
                self.module.fail_json( 
                    msg='Erreur durant la {}. Le royaume {} existe mais impossible d\'y accéder, vérifiez vos credentials: {}'
                        .format(gestion_erreur, realm, str(e)),
                    exception=traceback.format_exc()
                )
            else:
                self.module.fail_json( 
                    msg='Erreur durant la {}. Le royaume {} n\'existe peut-être pas- ?: {}'
                        .format(gestion_erreur, realm, str(e)),
                    exception=traceback.format_exc()
                )
        except ValueError as e:
            self.module.fail_json( 
                msg='Erreur durant la {}. L\'API retourne un JSON incorrect en essayant d\'accéder au royaume {}: {}'
                    .format(gestion_erreur, realm, str(e)),
                exception=traceback.format_exc()
            )
        except Exception as e:
            self.module.fail_json( 
                msg='Erreur inconnue durant la {}. Impossible d\'accéder au royaume {}: {}'
                    .format(gestion_erreur, realm, str(e)),
                exception=traceback.format_exc()
            )
        

module = AnsibleModule(  
    dict(
        keycloak_url = dict( type='str', aliases=['url'], required=True),
        realm = dict( type='str', required=True),
        username = dict( type='str', required=True),
        password = dict( type='str', required=True,  no_log=True),
        token = dict( type='str' )
    ), 
    supports_check_mode = True
)

# Obtention du token et initialisation de l'API
try:
    connection_header = get_token( module.params )
except KeycloakError as e:
    module.fail_json( msg = str(e) )
# connection_header = get_token( module.params )

kc = KeycloakAPI( module, connection_header)

# Vérifier l'existence du royaume
realm = kc.get_realm_by_id()

# if realm is None:
#     result['msg'] = "Le royaume n'existe pas"
#     module.fail_json(**result)

user_info = kc.get_user_info()

if user_info is None:
    module.fail_json( 
        msg='Impossible de trouver les infos de l\'utilisateur, vérifiez vos paramètres',
        exception=traceback.format_exc()
    )

module.exit_json(
    msg="Infos de l\'utilisateur : {}".format(to_text(user_info))
)

